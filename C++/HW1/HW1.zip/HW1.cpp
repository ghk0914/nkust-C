#include <iostream>
#include <iomanip>
using namespace std;;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	cout<<"1X2=2 2X1=2 1X4=4 2X3=6 3X2=6 4X1=4 1X6=6 2X5=10 3X4=12"<<endl;
	cout<<"4X3=12 5X2=10 6X1=6 1X8=8 2X7=14 3X6=18 4X5=20 5X4=20 6X3=18"<<endl;
	cout<<"7X2=14 8X1=8 2X9=18 3X8=24 4X7=28 5X6=30 6X5=30 7X4=28 8X3=24"<<endl;
	cout<<"9X2=18 4X9=36 5X8=40 6X7=42 7X6=42 8X5=40 9X4=36 6X9=54 7X8=56"<<endl;
	cout<<"8X7=56 9X6=54 8X9=72 9X8=72 1X1=1 1X3=3 1X5=5 1X7=7 1X9=9"<<endl;
	cout<<"2X2=4 2X4=8 2X6=12 2X8=16 3X1=3 3X3=9 3X5=15 3X7=21 3X9=27"<<endl;
	cout<<"4X2=8 4X4=16 4X6=24 4X8=32 5X1=5 5X3=15 5X5=25 5X7=35 5X9=45"<<endl;
	cout<<"6X2=12 6X4=24 6X6=36 6X8=48 7X1=7 7X3=21 7X5=35 7X7=49 7X9=63"<<endl;
	cout<<"8X2=16 8X4=32 8X6=48 8X8=64 9X1=9 9X3=27 9X5=45 9X7=63 9X9=81"<<endl; 
		return 0;
}
